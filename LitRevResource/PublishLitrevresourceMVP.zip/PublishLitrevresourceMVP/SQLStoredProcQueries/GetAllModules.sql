SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- By LAJ, on 02/08/2022, for LitrevresourceDB
CREATE PROCEDURE AddModule
	
AS
BEGIN
	
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT * from Module_table
END
GO
